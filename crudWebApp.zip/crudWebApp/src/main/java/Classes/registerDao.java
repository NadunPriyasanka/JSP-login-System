package Classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class registerDao {
	String dbdriver="com.mysql.cj.jdbc.Driver";
	
public void LoadDriver(String dbdriver)
{
	try {
		Class.forName(dbdriver);
	} catch (ClassNotFoundException e) {
		
		e.printStackTrace();
	}	
}
public Connection getConnection()
{
	Connection con=null;
	try
	{
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/web?useSSl=false","root","");
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
	return con;
	
}
public String insert(Member member)
{
	LoadDriver(dbdriver);
	Connection con=getConnection();
	String sql="insert into user values(?,?,?,?)";
	
	String result="Insert successfull !";
	try {
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1,member.getName());
		ps.setString(2,member.getEmail());
		ps.setString(3, member.getPass());
		ps.setString(4, member.getNum());
		ps.executeUpdate();
		
	} catch (SQLException e) {

		e.printStackTrace();
		 result="Insert faild !";
	}
	
	
	return result;
	
}

}
