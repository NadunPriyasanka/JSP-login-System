package Servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import Classes.Member;
import Classes.registerDao;


public class register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String pass = request.getParameter("pass");
		String num = request.getParameter("num");
		
		Member member=new Member(name,email,pass,num);
		registerDao rdao = new registerDao();
		
		RequestDispatcher rd=request.getRequestDispatcher("regOK.jsp");
		rd.forward(request, response);
		String result=rdao.insert(member);
		response.getWriter().println(result);
		
	}

}
